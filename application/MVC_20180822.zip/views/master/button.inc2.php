<button name="btnSimpan" class="btn blue" id="id_btnSimpan" title="Simpan">
    <span class="glyphicon glyphicon-floppy-disk"></span> <!--Simpan-->
</button>
<button name="btnUbah" onclick="" class="btn yellow" id="id_btnUbah" title="Ubah">
    <span class="glyphicon glyphicon-edit"></span> <!--Ubah-->
</button>
<!-- <button name="btnHapus" class="btn red" id="id_btnHapus" title="Hapus">
    <span class="glyphicon glyphicon-trash"></span>
</button> -->
<button id="id_btnBatal" type="reset" class="btn default"  title="Batal/Refresh">
    <span class="glyphicon glyphicon-refresh"></span>
    <!--Batal-->
</button>