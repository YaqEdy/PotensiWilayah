<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );

class Sec_aktivasi_m extends CI_Model {
	
	
}

/* End of file sec_menu_user_m.php */
/* Location: ./application/models/sec_menu_user.php */